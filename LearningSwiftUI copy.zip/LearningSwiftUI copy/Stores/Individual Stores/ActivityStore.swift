//
//  ActivityStore.swift
//  LearningSwiftUI
//
//  Created by Ohad Naor on 18/11/2025.
//

//final class ActivityStore: ObservableObject {
//    @Published var activities: [Activity] = []
//}
